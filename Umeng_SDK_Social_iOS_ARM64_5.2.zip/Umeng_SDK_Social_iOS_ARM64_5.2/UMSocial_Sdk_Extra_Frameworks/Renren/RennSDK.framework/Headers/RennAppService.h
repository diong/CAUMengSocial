//
//  RennAppService.h
//  RennSDK
//
//  Created by 杨 飞 on 13-5-13.
//  Copyright (c) 2013年 Li Chengliang. All rights reserved.
//

#import "RennParam.h"

extern NSString *kRennServiceTypeGetApp;

/*
 API链接: http://wiki.dev.renren.com/wiki/V2/app/get
 */
@interface GetAppParam : RennParam

@end
